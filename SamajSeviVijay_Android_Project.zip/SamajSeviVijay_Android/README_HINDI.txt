समाज सेवी विजय — Android Studio प्रोजेक्ट

इस ZIP में विजय मीना जी की फोटो वाला Android ऐप प्रोजेक्ट है।

APK बनाने का तरीका:
1. कंप्यूटर में Android Studio इंस्टॉल करें।
2. इस ZIP को Extract करें।
3. Android Studio में Open चुनकर SamajSeviVijay फ़ोल्डर खोलें।
4. Gradle Sync पूरा होने दें।
5. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
6. APK app/build/outputs/apk/debug/app-debug.apk में बनेगा।

वैकल्पिक: GitHub पर इस प्रोजेक्ट को main branch में डालें। Actions टैब में
Build Android APK workflow चलाएँ। पूरा होने पर Samaj-Sevi-Vijay-APK artifact
से app-debug.apk डाउनलोड करें।

महत्वपूर्ण:
- यह अभी लोकल डेमो ऐप है।
- नाम/मोबाइल लॉगिन OTP से सत्यापित नहीं है।
- डेमो एडमिन PIN 3620 है; इसे सार्वजनिक रूप से सुरक्षित न मानें।
- सूचनाएँ केवल उसी फोन में सेव होती हैं। सभी फोन पर नोटिफिकेशन भेजने के लिए
  अलग सुरक्षित backend, database, admin login और push notifications जोड़ने होंगे।
